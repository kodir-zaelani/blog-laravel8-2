<footer class="main-footer">
    <b>V 1.0 | </b>
    <strong>Copyright &copy; 2020 - @php
        echo  date('Y');
    @endphp |  <a href="http://{{ $global_settings->website }}">{{ $global_settings->title }}</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>Developed : Laman Kreasi</b>
    </div>
</footer>