<div>
    @if ($statusShow)
        @livewire('frontend.post.show')
     @else
        @livewire('frontend.main.home')
    @endif
</div>
