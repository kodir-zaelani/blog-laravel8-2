<div>
    
    @livewire('frontend.main.banner')
    
    @livewire('frontend.post.index')

    @livewire('frontend.post.categorypostindex')
    
    @livewire('frontend.photo.index')
    
</div>
