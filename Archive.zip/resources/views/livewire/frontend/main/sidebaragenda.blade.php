<div>
    <div class="row mb-3">
        <div class="col-12">
            <!-- agenda section -->
            <div class="card card-primary mb-3" >
                <div class="card-header" >
                  <h4><i class="fa fa-calendar" aria-hidden="true"></i> AGENDA TERBARU</h4>
                </div>
                <div class="card-body">
                  <div class="card mb-3 shadow-sm border-0">
                    <div class="card-body">
                      <h6>Lorem ipsum dolor sit amet, consectetur adipisicing elit</h6>
                      <hr>
                      <div>
                        <i class="fa fa-map-marker" aria-hidden="true"></i> Aula Sekolah
                      </div>
                      <div class="mt-2">
                        <i class="fa fa-calendar" aria-hidden="true"></i> 20 Juli 2020
                      </div>
                    </div>
                  </div>
                  
                  <div class="card mb-3 shadow-sm border-0">
                    <div class="card-body">
                      <h6>Lorem ipsum dolor sit amet, consectetur adipisicing elit</h6>
                      <hr>
                      <div>
                        <i class="fa fa-map-marker" aria-hidden="true"></i> Aula Sekolah
                      </div>
                      <div class="mt-2">
                        <i class="fa fa-calendar" aria-hidden="true"></i> 20 Juli 2020
                      </div>
                    </div>
                  </div>
                  
                  <div class="card mb-3 shadow-sm border-0">
                    <div class="card-body">
                      <h6>Lorem ipsum dolor sit amet, consectetur adipisicing elit</h6>
                      <hr>
                      <div>
                        <i class="fa fa-map-marker" aria-hidden="true"></i> Aula Sekolah
                      </div>
                      <div class="mt-2">
                        <i class="fa fa-calendar" aria-hidden="true"></i> 20 Juli 2020
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <!-- end agenda section -->
        </div>
    </div>
</div>
