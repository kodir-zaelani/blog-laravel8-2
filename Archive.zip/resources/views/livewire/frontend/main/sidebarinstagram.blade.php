<div>
    
            <!-- Instagram -->
            <div class="card card-primary mb-3" >
                <div class="card-header" >
                  <h4><i class="fab fa-instagram-square"></i> Instagram</h4>
                </div>
                <div class="card-body text-center">
                  {!! $global_social->instagram_embed !!}
                </div>
              </div>
              <!-- Instagram -->
        
</div>
