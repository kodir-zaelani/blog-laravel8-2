<div>
    <div class="row mb-3">
        <div class="col-12">
            <!-- Links -->
            <div class="card card-primary " >
                <div class="card-header" >
                  <h4><i class="fas fa-link"></i> Links</h4>
                </div>
                <div class="card-body">
                  <div class="list-group">
                    <a href="" class="list-group-item list-group-item-action border-0 shadow-sm mb-2 rounded"><i class="fa fa-folder-open" aria-hidden="true"></i> OSIS</a>
                    
                    <a href="" class="list-group-item list-group-item-action border-0 shadow-sm mb-2 rounded"><i class="fa fa-folder-open" aria-hidden="true"></i> PRAMUKA</a>
                    
                    <a href="" class="list-group-item list-group-item-action border-0 shadow-sm mb-2 rounded"><i class="fa fa-folder-open" aria-hidden="true"></i> BERITA</a>
                    
                    
                    <a href="" class="list-group-item list-group-item-action border-0 shadow-sm mb-2 rounded"><i class="fa fa-folder-open" aria-hidden="true"></i> INFO</a>
                  </div>
                </div>
              </div>
              <!-- Links -->
        </div>
    </div>
</div>
