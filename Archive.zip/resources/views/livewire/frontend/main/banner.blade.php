<div>
    <!-- Home Banner -->
    <header class="main-banner">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 col-md-7">
                    <div class="row">
                        <div class="col-12">
                            <div class="banner-title">
                                @if ($global_settings->title)
                                    <h2>{!! $global_settings->title !!}</h2>
                                @else
                                <h2>Laman Kreasi Nusantara</h2>
                                @endif
                                @if ($global_settings->tagline)
                                <h4 class="card-title">{!! $global_settings->tagline !!}</h4>
                                @else
                                    <h4>Ayo semangat belajar</h4>
                                @endif 
                                @if ($global_settings->description)
                                    <p>{!! $global_settings->description !!}</p>
                                @else
                                    <p>Melalui website ini semoga dapat menjadi sarana upaya peningkatan kompetensi</p>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5 col-md-5">
                    <div class="main-banner-content">
                        <img src="{{ url('') }}/assets/frontend/image/hero.png" style="max-width: 90%">
                    </div>
                </div>
            </div>
        </div>
    </header>
</div>
