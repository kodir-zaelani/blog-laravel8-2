<div>
    <div class="row mb-3">
        <div class="col-12">
            <!-- Facebook -->
            <div class="card card-primary" >
                <div class="card-header" >
                  <h4><i class="fab fa-facebook-square"></i> Facebook</h4>
                </div>
                <div class="card-body text-center">
                  {!! $global_social->facebook_embed !!}
                </div>
              </div>
              <!-- Facebook -->
        </div>
    </div>
</div>
