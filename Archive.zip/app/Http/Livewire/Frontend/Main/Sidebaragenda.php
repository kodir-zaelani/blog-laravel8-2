<?php

namespace App\Http\Livewire\Frontend\Main;

use Livewire\Component;

class Sidebaragenda extends Component
{
    public function render()
    {
        return view('livewire.frontend.main.sidebaragenda');
    }
}
