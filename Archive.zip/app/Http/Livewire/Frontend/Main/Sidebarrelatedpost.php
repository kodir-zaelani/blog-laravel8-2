<?php

namespace App\Http\Livewire\Frontend\Main;

use Livewire\Component;

class Sidebarrelatedpost extends Component
{
    public function render()
    {
        return view('livewire.frontend.main.sidebarrelatedpost');
    }
}
