<?php

namespace App\Http\Livewire\Frontend\Download;

use App\Models\Downloadfile;
use Livewire\Component;

class Detail extends Component
{
    public  $downloadfile;

    public function mount(Downloadfile $downloadfile)
    {
        $downloadfile->increment('download_count');

        $this->downloadfile = $downloadfile;
    }

    public function render()
    {
        return view('livewire.frontend.download.detail')
        ->extends('layouts.appfrontendfile')
        ->section('content');
    }
}
