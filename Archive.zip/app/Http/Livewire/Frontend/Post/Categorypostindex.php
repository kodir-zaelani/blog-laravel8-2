<?php

namespace App\Http\Livewire\Frontend\Post;

use App\Models\Post;
use Livewire\Component;
use App\Models\Categorypost;

class Categorypostindex extends Component
{
    public function render()
    {
        $categoryposts = Categorypost::orderBy('id', 'asc')
                        ->with('post')
                        ->get();

        return view('livewire.frontend.post.categorypostindex', compact('categoryposts'));
    }
}
