<?php

namespace App\Http\Livewire\Frontend\Post;

use Livewire\Component;

class Writer extends Component
{
    public function render()
    {
        return view('livewire.frontend.post.writer');
    }
}
