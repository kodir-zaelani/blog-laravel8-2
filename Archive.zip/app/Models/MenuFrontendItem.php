<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MenuFrontendItem extends Model
{
    // use HasFactory;
    protected $table = 'admin_menu_items';
    protected $guarded = [];

}
