<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class EmployeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //

        $faker = \Faker\Factory::create('id_ID');

    	for($i = 1; $i <= 30; $i++){

    	      // insert data ke table pegawai menggunakan Faker
    		DB::table('employes')->insert([
    			'nama' => $faker->name,
    			'email' => $faker->email,
    			'alamat' => $faker->address,
    			'telephone' => $faker->phoneNumber,
    			'pekerjaan' => 'karyawan'
    		]);

    	}

    }
}
