<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    
    
    <title><?php echo $__env->yieldContent('title', 'Laman Kreasi'); ?></title>
    
    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">
    
    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(url('')); ?>/assets/frontend/css/bootstrap.min.css">
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="<?php echo e(url('')); ?>/assets/frontend/plugins/fontawesome/css/all.min.css">
    <link rel="stylesheet" href="<?php echo e(url('')); ?>/assets/frontend/css/fancybox.min.css">
    
    <link rel="stylesheet" href="<?php echo e(url('')); ?>/assets/frontend/css/cubeportfolio.min.css">
    <link rel="stylesheet" href="<?php echo e(url('')); ?>/assets/frontend/css/dzsparallaxer.min.css">
    <?php echo $__env->yieldPushContent('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(url('')); ?>/assets/frontend/css/styles.css">
    <link rel="stylesheet" href="<?php echo e(url('')); ?>/assets/frontend/css/responsive.css">
    
    <?php echo \Livewire\Livewire::styles(); ?>

    
</head>
<body>
    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.main.header')->html();
} elseif ($_instance->childHasBeenRendered('wbngl8o')) {
    $componentId = $_instance->getRenderedChildComponentId('wbngl8o');
    $componentTag = $_instance->getRenderedChildComponentTagName('wbngl8o');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('wbngl8o');
} else {
    $response = \Livewire\Livewire::mount('frontend.main.header');
    $html = $response->html();
    $_instance->logRenderedChild('wbngl8o', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
   
        <?php echo $__env->yieldContent('content'); ?>
        
        
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.main.footer')->html();
} elseif ($_instance->childHasBeenRendered('lchYbSs')) {
    $componentId = $_instance->getRenderedChildComponentId('lchYbSs');
    $componentTag = $_instance->getRenderedChildComponentTagName('lchYbSs');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('lchYbSs');
} else {
    $response = \Livewire\Livewire::mount('frontend.main.footer');
    $html = $response->html();
    $_instance->logRenderedChild('lchYbSs', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    
    <?php echo $__env->yieldPushContent('modals'); ?>
    <!-- Bootstrap JS -->
    <script src="<?php echo e(url('')); ?>/assets/frontend/plugins/jquery/jquery-3.5.1.min.js"></script>
    <script src="<?php echo e(url('')); ?>/assets/frontend/js/jquery-migrate.min.js"></script>
    <script src="<?php echo e(url('')); ?>/assets/frontend/js/jquery-ui.min.js"></script>
    <script src="<?php echo e(url('')); ?>/assets/frontend/js/modernizr.min.js"></script>
    <script src="<?php echo e(url('')); ?>/assets/frontend/js/bootstrap.bundle.min.js"></script>
    
    <!-- Particles JS -->
    <script src="<?php echo e(url('')); ?>/assets/frontend/js/particles.min.js"></script>
    <script src="<?php echo e(url('')); ?>/assets/frontend/js/particle-active.js"></script>
    <script src="<?php echo e(url('')); ?>/assets/frontend/js/theme.js"></script>
    <script src="<?php echo e(url('')); ?>/assets/frontend/js/main.js"></script>
    
    <?php echo $__env->yieldPushContent('scripts'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

</body>
</html>
<?php /**PATH /Users/kodir78/Sites/laman8/resources/views/layouts/appfrontend.blade.php ENDPATH**/ ?>