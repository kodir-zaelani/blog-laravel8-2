<footer class="main-footer">
    <b>V 1.0 | </b>
    <strong>Copyright &copy; 2020 - <?php
        echo  date('Y');
    ?> |  <a href="http://<?php echo e($global_settings->website); ?>"><?php echo e($global_settings->title); ?></a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>Developed : Laman Kreasi</b>
    </div>
</footer><?php /**PATH /Users/kodir78/Sites/laman8/resources/views/admin/templates/partials/footer.blade.php ENDPATH**/ ?>