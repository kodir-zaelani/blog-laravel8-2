<div>
    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.main.banner')->html();
} elseif ($_instance->childHasBeenRendered('YJLMJOR')) {
    $componentId = $_instance->getRenderedChildComponentId('YJLMJOR');
    $componentTag = $_instance->getRenderedChildComponentTagName('YJLMJOR');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('YJLMJOR');
} else {
    $response = \Livewire\Livewire::mount('frontend.main.banner');
    $html = $response->html();
    $_instance->logRenderedChild('YJLMJOR', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.post.index')->html();
} elseif ($_instance->childHasBeenRendered('C5PTzYH')) {
    $componentId = $_instance->getRenderedChildComponentId('C5PTzYH');
    $componentTag = $_instance->getRenderedChildComponentTagName('C5PTzYH');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('C5PTzYH');
} else {
    $response = \Livewire\Livewire::mount('frontend.post.index');
    $html = $response->html();
    $_instance->logRenderedChild('C5PTzYH', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.post.categorypostindex')->html();
} elseif ($_instance->childHasBeenRendered('4yStK7o')) {
    $componentId = $_instance->getRenderedChildComponentId('4yStK7o');
    $componentTag = $_instance->getRenderedChildComponentTagName('4yStK7o');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('4yStK7o');
} else {
    $response = \Livewire\Livewire::mount('frontend.post.categorypostindex');
    $html = $response->html();
    $_instance->logRenderedChild('4yStK7o', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.photo.index')->html();
} elseif ($_instance->childHasBeenRendered('hZdmOEI')) {
    $componentId = $_instance->getRenderedChildComponentId('hZdmOEI');
    $componentTag = $_instance->getRenderedChildComponentTagName('hZdmOEI');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('hZdmOEI');
} else {
    $response = \Livewire\Livewire::mount('frontend.photo.index');
    $html = $response->html();
    $_instance->logRenderedChild('hZdmOEI', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    
</div>
<?php /**PATH /Users/kodir78/Sites/laman8/resources/views/livewire/frontend/main/home.blade.php ENDPATH**/ ?>