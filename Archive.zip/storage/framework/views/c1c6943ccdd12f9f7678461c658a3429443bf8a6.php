<div>
    <!-- Blog Category -->
    <?php if($pageprofile->count()>0): ?>
    <div class="row">
        <div class="col-12">
            <div class="card card-primary mb-3" >
                <div class="card-header" >
                  <h4><i class="fa fa-folder" aria-hidden="true"></i> PROFIL</h4>
                </div>
                <div class="card-body categorys">
                  <div class="list-group">
        
                    <?php $__currentLoopData = $pageprofile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <a href="<?php echo e(route('page.show', $page->slug)); ?>" class="list-group-item list-group-item-action border-0 shadow-sm mb-2 rounded"><i class="fa fa-folder" aria-hidden="true"></i> 
                            <?php echo e($page->title); ?>

                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php if($pagesarpras->count()>0): ?>
    <div class="row">
        <div class="col-12">
            <div class="card card-primary mb-3" >
                <div class="card-header" >
                  <h4><i class="fa fa-folder" aria-hidden="true"></i> PROFIL</h4>
                </div>
                <div class="card-body categorys">
                  <div class="list-group">
        
                    <?php $__currentLoopData = $pageprofile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       
                         <a href="<?php echo e(route('page.show', $page->slug)); ?>" class="list-group-item list-group-item-action border-0 shadow-sm mb-2 rounded"><i class="fa fa-folder" aria-hidden="true"></i> 
                            <?php echo e($page->title); ?>

                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <!--/ End Blog Category -->
</div>
<?php /**PATH /Users/kodir78/Sites/laman8/resources/views/livewire/frontend/main/sidebarpage.blade.php ENDPATH**/ ?>