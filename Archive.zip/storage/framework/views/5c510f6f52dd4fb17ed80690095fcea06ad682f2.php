<div>
    <?php if(count($photos)): ?>
    <section class="portfolio section mt-5">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 text-center">
                  <h4 class="font-weight-bold mb-3 mx-3">PORTFOLIO</h4>
                </div>
              </div>
            <div class="row">
                <div class="col-12">
                    <!-- portfolio Nav -->
                    <div class="portfolio-nav">
                        <ul class="tr-list list-inline cbp-l-filters-work" id="portfolio-menu">
                            <li data-filter="*" class="cbp-filter-item active">All<div class="cbp-filter-counter"></div>
                            </li>  
                            <?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(count($album->photo()->get())): ?>
                                <li data-filter=".<?php echo e($album->slug); ?>" class="cbp-filter-item"><?php echo e($album->title); ?><div class="cbp-filter-counter"></div>
                                </li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
                        </ul>  		
                    </div>
                    <!--/ End portfolio Nav -->
                </div>
            </div>
            
            <div class="portfolio-inner">
                <div id="portfolio-item">
                    <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="cbp-item development <?php echo e($photo->album->slug); ?> ">
                        <div class="portfolio-single">
                            <div class="portfolio-head">
                                <?php if($photo->ImageThumbUrl): ?>
                                <img src="<?php echo e($photo->ImageThumbUrl); ?>" alt="#"/>
                                <?php else: ?>
                                <img src="assets/kz/images/gallery-1.jpg" alt="#"/>
                                <?php endif; ?>
                                <div class="portfolio-hover">
                                    <h4><?php echo e($photo->title); ?></h4>
                                    <div class="p-button">
                                        <a data-fancybox="portfolio" href="<?php echo e($photo->ImageUrl); ?>" data-caption="<?php echo e($photo->title); ?>" class="btn primary"><i class="fas fa-image"></i></a>
                                        <a href="#" class="btn primary" title="Album <?php echo e($photo->album->title); ?>"><i class="fa fa-link"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <!-- Load More Button -->
                <div class="row text-center mt-4">
                    <div class="col-12 ">
                    

                        
                    </div>
                </div>
                <!--/ End Load More Button -->
            </div>

        </div>
    </section>
    <?php else: ?>
        
    <?php endif; ?>
</div>
<?php /**PATH /Users/kodir78/Sites/laman8/resources/views/livewire/frontend/photo/index.blade.php ENDPATH**/ ?>