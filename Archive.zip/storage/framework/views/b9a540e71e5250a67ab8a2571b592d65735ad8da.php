 <!-- Navbar -->
 <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="<?php echo e(route('root')); ?>" class="nav-link" target="_blank">View Site</a>
      </li>
    </ul>

    <!-- SEARCH FORM -->
    

    <!-- Right navbar links -->
    <ul class="ml-auto navbar-nav">
      <!-- Messages Dropdown Menu -->
      
      <li class="nav-item dropdown user-menu">
        <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
            <?php if(auth()->user()->profile_photo_path): ?>
                <img class="user-image img-circle elevation-2"
                src="<?php echo e(url('')); ?>/uploads/photos/users/photos_thumb/<?php echo e(auth()->user()->profile_photo_path); ?>"
                alt="<?php echo e(auth()->user()->name); ?>">
            <?php else: ?>
                <img src="<?php echo e(url('')); ?>/assets/admin/dist/img/avatar.png" class="user-image img-circle elevation-2" alt="<?php echo e(auth()->user()->name); ?>">
            <?php endif; ?>
          <span class="d-none d-md-inline"><?php echo e(Auth::user()->name); ?> <i class="fas fa-angle-down"></i></span>
        </a>
        <ul class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <!-- User image -->
          <li class="user-header bg-primary">
            <?php if(auth()->user()->profile_photo_path): ?>
                <img class="img-circle elevation-2"
                src="<?php echo e(url('')); ?>/uploads/photos/users/photos_thumb/<?php echo e(auth()->user()->profile_photo_path); ?>"
                alt="<?php echo e(auth()->user()->name); ?>">
            <?php else: ?>
                <img src="<?php echo e(url('')); ?>/assets/admin/dist/img/avatar.png" class="img-circle elevation-2" alt="<?php echo e(auth()->user()->name); ?>">
            <?php endif; ?>
            <p>
              <?php echo e(Auth::user()->name); ?>

              <small>Member since <?php echo e(Auth::user()->created_at->diffForHumans()); ?></small>
            </p>
          </li>
          <!-- Menu Body -->
          
          <!-- Menu Footer-->
          <li class="user-footer">
            <a href="<?php echo e(route('admin.users.profile')); ?>" class="btn btn-default btn-flat">My Profile</a>
            <a href="<?php echo e(route('logout')); ?>"
            onclick="event.preventDefault();
                          document.getElementById('logout-form').submit();" class="float-right btn btn-default btn-flat">Sign out</a>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
              <?php echo csrf_field(); ?>
          </form>
          </li>
        </ul>
      </li>

    </ul>
  </nav>
  <!-- /.navbar --><?php /**PATH /Users/kodir78/Sites/laman8/resources/views/admin/templates/partials/navbar.blade.php ENDPATH**/ ?>