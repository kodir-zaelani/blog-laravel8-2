<?php $__env->startSection("title"); ?>Roles <?php $__env->stopSection(); ?>
<?php $__env->startSection("subtitle"); ?>List Roles <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-header">
    <div class="container-fluid">
        <div class="mb-2 row">
            <div class="col-sm-6">
                <h1 class="m-0 text-dark"><?php echo $__env->yieldContent('title'); ?></h1>
            </div>
            <div class="col-sm-6 ">
                <ol class="breadcrumb float-sm-right">
                    
                </ol>
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.roles.index')); ?>"><?php echo $__env->yieldContent('title'); ?></a>
                        </li>
                    <li class="breadcrumb-item active"><?php echo $__env->yieldContent('subtitle'); ?></li>
                </ol>
            </div>
        </div>
    </div>
</div>
<section class="content">
    <div class="container-fluid">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.role.index')->html();
} elseif ($_instance->childHasBeenRendered('yrJ4jZv')) {
    $componentId = $_instance->getRenderedChildComponentId('yrJ4jZv');
    $componentTag = $_instance->getRenderedChildComponentTagName('yrJ4jZv');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('yrJ4jZv');
} else {
    $response = \Livewire\Livewire::mount('admin.role.index');
    $html = $response->html();
    $_instance->logRenderedChild('yrJ4jZv', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.templates.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/kodir78/Sites/laman8/resources/views/admin/role/index.blade.php ENDPATH**/ ?>