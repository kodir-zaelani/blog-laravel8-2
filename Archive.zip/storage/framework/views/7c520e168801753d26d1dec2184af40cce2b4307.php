<?php $__env->startSection("title"); ?>Menu <?php $__env->stopSection(); ?>
<?php $__env->startSection("subtitle"); ?>List Menu <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0 text-dark"><?php echo $__env->yieldContent('title'); ?></h1>
            </div>
            <div class="col-sm-6 ">
                <ol class="breadcrumb float-sm-right">
                    
                </ol>
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.menus.index')); ?>"><?php echo $__env->yieldContent('title'); ?></a>
                        </li>
                    <li class="breadcrumb-item active"><?php echo $__env->yieldContent('subtitle'); ?></li>
                </ol>
            </div>
        </div>
    </div>
</div>
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title">Manage Menu</h3>
                    </div>
                    <div class="card-body ">
                        <?php echo Menu::render(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
<link href="<?php echo e(asset('vendor/harimayco-menu/style.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
    <?php echo Menu::scripts(); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.templates.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/kodir78/Sites/laman8/resources/views/admin/dashboard/menu.blade.php ENDPATH**/ ?>