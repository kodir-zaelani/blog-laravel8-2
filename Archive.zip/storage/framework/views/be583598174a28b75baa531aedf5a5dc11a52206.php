<div>
    <div class="cta-header pt-5">
        <div class="container-fluid">
            <div class="row justify-content-center pt-5">
                <div class="col-lg-6 col-md-6 col-12">
                    <div class="cta-header-title text-center">
                        <h2 class="py-4 text-uppercase font-weight-bold">DAFTAR UNDUH</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row py-2">
            <div class="col-md-12">
                <div class="card card-primary">
                    
                    <div class="card-body ">
                        
                        <div class="my-3 row">
                            <div class="col">
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                      <label class="mr-2" for="inputGroupSelect01">Show</label>
                                    </div>
                                    <select wire:model="paginate" class="custom-select py-1 " id="inputGroupSelect01">
                                      <option selected value="5">5</option>
                                      <option value="10">10</option>
                                      <option value="25">25</option>
                                      <option value="50">50</option>
                                      <option value="100">100</option>
                                    </select>
                                    <div class="input-group-append">
                                        <label class="ml-2" for="inputGroupSelect01">entries</label>
                                      </div>
                                    
                                  </div>
                                  
                        
                            </div>
                            
                            <div class="col">
                                <div class="float-right">
                                    <div class="input-group" style="">
                                        <input type="text" wire:model="search" 
                                        wire:keydown.escape="resetSearch"
                                        wire:keydown.tab="resetSearch" class="form-control float-right" placeholder="Title Search...">
                                        <div class="input-group-append">
                                          <button type="submit" class="btn btn-default"><i class="fas fa-search"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
    
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-12">
                                <div class="table-responsive">
                                    <table id="dataTable" class="table table-bordered" style="width=100%">
                                    <thead class="text-center thead-dark"">
                                        <th width="4%" scope="col">#</th>
                                        <th scope="col" >Title</th>
                                        <th scope="col" width="10%">Action</th>
                                    </thead>
                                    <tbody>
                                        
                                        <?php $__currentLoopData = $downloadfiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th class="text-right" scope="row"><?php echo e($no + $downloadfiles->firstItem()); ?></th>
                                            <td>
                                                <?php echo e($item->title); ?><br>
                                            </td>
                                            <td class="text-center">
                                                <?php if($item->file ): ?>
                                                    <a href="<?php echo e(url('')); ?>/uploads/downloadfiles/<?php echo e($item->file); ?>" target="_blank" class="btn btn-sm btn-success"><i class="far fa-eye"></i></a>
                                                <?php else: ?>
                                                    <a href="<?php echo e($item->linkfile); ?>" target="_blank" class="btn btn-sm btn-success"><i class="far fa-eye"></i></a>
                                                <?php endif; ?>
                                                
                                              
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        
                        <div class="mt-3 row justify-content-center">
                            <div class="col-md-8 col-lg-8 col-12">
                                <?php echo e($downloadfiles->links()); ?>

                            </div>
                           <div class="col-md-4 col-lg-4 col-12">
                            <div class="text-center">
                                Page : <?php echo e($downloadfiles->currentPage()); ?> | Show <?php echo e($downloadfiles->count()); ?>  of <?php echo e($downloadfiles->total()); ?>

                            </div>
                           </div>
                        </div>
                       
                    </div>
                </div>
            </div>
        </div> 
    </div>
    
</div>
<?php /**PATH /Users/kodir78/Sites/laman8/resources/views/livewire/frontend/download/index.blade.php ENDPATH**/ ?>