<div>
    <!-- Porfolio -->
    <section class="portfolio">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 text-center">
                    <h2 class="font-weight-bold">Portfolio</h2>
                    <!-- <p>Sed lorem enim, faucibus at erat eget, laoreet tincidunt tortor. Ut sed mi nec ligula bibendum aliquam. Sed scelerisque maximus magna, a vehicula turpis Proin</p> -->
                </div>
            </div> 
        </div> 
        <div class="row">
            <div class="col-12">
                <!-- portfolio Nav -->
                <div class="portfolio-nav">
                    <ul class="tr-list list-inline cbp-l-filters-work" id="portfolio-menu">
                        <li data-filter="*" class="cbp-filter-item active">All<div class="cbp-filter-counter"></div></li>  
                        <li data-filter=".website" class="cbp-filter-item">Website<div class="cbp-filter-counter"></div></li>
                        <li data-filter=".branding" class="cbp-filter-item">Branding<div class="cbp-filter-counter"></div></li>
                        <li data-filter=".package" class="cbp-filter-item">Package<div class="cbp-filter-counter"></div></li>
                        <li data-filter=".development" class="cbp-filter-item">Development<div class="cbp-filter-counter"></div></li>
                        <li data-filter=".printing" class="cbp-filter-item">Printing<div class="cbp-filter-counter"></div></li>
                    </ul>  		
                </div>
                <!--/ End portfolio Nav -->
            </div>
        </div>
        <div class="portfolio-inner">
            <div id="portfolio-item">
                <!-- Single portfolio -->
                <div class="cbp-item website package">
                    <div class="portfolio-single">
                        <div class="portfolio-head">
                            <img src="assets/image/edu1.jpg" alt="#"/>
                            <div class="portfolio-hover">
                                <h4 class="card-title"><a href="portfolio-single.html">Creative Work</a></h4>
                                <div class="p-button">
                                    <a href="https://www.youtube.com/embed/UalTfOIDQ7M" class="btn primary video-play cbp-lightbox"><i class="fa fa-play"></i></a>
                                    <a href="portfolio-single.html" class="btn"><i class="fa fa-link"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--/ End portfolio -->	
                <!-- Single portfolio -->
                <div class="cbp-item development printing">
                    <div class="portfolio-single">
                        <div class="portfolio-head">
                            <img src="assets/image/edu2.jpeg" alt="#"/>
                            <div class="portfolio-hover">
                                <h4 class="card-title"><a href="portfolio-single.html">Animation</a></h4>
                                <div class="p-button">
                                    <a data-fancybox="portfolio" href="assets/image/edu2.jpeg" class="btn primary"><i class="fas fa-image"></i></a>
                                    <a href="portfolio-single.html" class="btn"><i class="fa fa-link"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--/ End portfolio -->	
                <!-- Single portfolio -->
                <div class="cbp-item development package">
                    <div class="portfolio-single">
                        <div class="portfolio-head">
                            <img src="assets/image/edu3.jpeg" alt="#"/>
                            <div class="portfolio-hover">
                                <h4 class="card-title"><a href="portfolio-single.html">Bootstrap 4</a></h4>
                                <div class="p-button">
                                    <a href="https://www.youtube.com/embed/gvzbqDc6AWI" class="btn primary video-play cbp-lightbox"><i class="fa fa-play"></i></a>
                                    <a href="portfolio-single.html" class="btn"><i class="fa fa-link"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--/ End portfolio -->	
                <!-- Single portfolio -->
                <div class="cbp-item website development">
                    <div class="portfolio-single">
                        <div class="portfolio-head">
                            <img src="assets/image/edu4.jpeg" alt="#"/>
                            <div class="portfolio-hover">
                                <h4 class="card-title"><a href="portfolio-single.html">Awesome Design</a></h4>
                                <div class="p-button">
                                    <a data-fancybox="portfolio" href="assets/image/edu4.jpeg" class="btn primary"><i class="fas fa-image"></i></a>
                                    <a href="portfolio-single.html" class="btn"><i class="fa fa-link"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--/ End portfolio -->	
                <!-- Single portfolio -->
                <div class="cbp-item website printing">
                    <div class="portfolio-single">
                        <div class="portfolio-head">
                            <img src="assets/image/edu5.jpeg" alt="#"/>
                            <div class="portfolio-hover">
                                <h4 class="card-title"><a href="portfolio-single.html">Branding</a></h4>
                                <div class="p-button">
                                    <a href="https://www.youtube.com/embed/UalTfOIDQ7M" class="btn primary video-play cbp-lightbox"><i class="fa fa-play"></i></a>
                                    <a href="portfolio-single.html" class="btn"><i class="fa fa-link"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--/ End portfolio -->	
                <!-- Single portfolio -->
                <div class="cbp-item branding website">
                    <div class="portfolio-single">
                        <div class="portfolio-head">
                            <img src="assets/image/edu6.jpeg" alt="#"/>
                            <div class="portfolio-hover">
                                <h4 class="card-title"><a href="portfolio-single.html">Gallery</a></h4>
                                <div class="p-button">
                                    <a data-fancybox="portfolio" href="assets/image/edu6.jpeg" class="btn primary"><i class="fas fa-image"></i></a>
                                    <a href="portfolio-single.html" class="btn"><i class="fa fa-link"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--/ End portfolio -->	
                <!-- Single portfolio -->
                <div class="cbp-item branding package">
                    <div class="portfolio-single">
                        <div class="portfolio-head">
                            <img src="assets/image/edu7.jpeg" alt="#"/>
                            <div class="portfolio-hover">
                                <h4 class="card-title"><a href="portfolio-single.html">Clean & modern</a></h4>
                                <div class="p-button">
                                    <a data-fancybox="portfolio" href="assets/image/edu7.jpeg" class="btn primary"><i class="fas fa-image"></i></a>
                                    <a href="portfolio-single.html" class="btn"><i class="fa fa-link"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--/ End portfolio -->	
                <!-- Single portfolio -->
                <div class="cbp-item printing website">
                    <div class="portfolio-single">
                        <div class="portfolio-head">
                            <img src="assets/image/edu8.jpeg" alt="#"/>
                            <div class="portfolio-hover">
                                <h4 class="card-title"><a href="portfolio-single.html">Development</a></h4>
                                <div class="p-button">
                                    <a href="https://www.youtube.com/embed/UalTfOIDQ7M" class="btn primary video-play cbp-lightbox"><i class="fa fa-play"></i></a>
                                    <a href="portfolio-single.html" class="btn"><i class="fa fa-link"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center pt-5">
                <div class="col-12 text-center">
                    <a href="#" class="btn btn-primary">Lihat Lebih Banyak</a>
                </div>
            </div>
        </div>
    </section>
    <!--/ End portfolio -->	
</div>
<?php /**PATH /Users/kodir78/Sites/laman8/resources/views/livewire/frontend/portfolio/portfoliohome.blade.php ENDPATH**/ ?>