<div>
    <!-- Blog Category -->
    <div class="row">
        <div class="col-12">
            <div class="card card-primary mb-3" >
                <div class="card-body">
                    <h4 class="font-weight-bold"><i class="fab fa-stack-overflow"></i> KATEGORI</h4>
                    <hr>
                  <div class="list-group my-3">
                    <?php $__currentLoopData = $categoryposts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->post->count()>0): ?>
                         <a href="<?php echo e(route('categorypost.show', $item->slug)); ?>" class="list-group-item list-group-item-action border-0 shadow-sm mb-2 rounded">
                        <span class="pull-left ">
                            <?php if($item->ImageThumbUrl): ?>
                            <img src="<?php echo e($item->imageThumbUrl); ?>" 
                            style="width: 50px;height: 50px" 
                            class="img-fluid rounded-circle mr-2" />
                            <?php else: ?>
                            <img src="<?php echo e(url('')); ?>/assets/help/img/edu5.jpeg"" 
                            style="width: 50px;height: 50px" 
                            class="img-fluid rounded-circle mr-2" />
                            <?php endif; ?>
                        </span> 
                            <?php echo e($item->title); ?>

                            
                        </a>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                </div>
            </div>
        </div>
    </div>
    <!--/ End Blog Category -->
</div>
<?php /**PATH /Users/kodir78/Sites/laman8/resources/views/livewire/frontend/main/sidebarcategory.blade.php ENDPATH**/ ?>