<?php $__env->startSection('title', 'Permission'); ?> 
<?php $__env->startSection('subtitle', 'List Permission'); ?> 
<?php $__env->startSection('content'); ?>
<div class="content-header">
    <div class="container-fluid">
        <div class="mb-2 row">
            <div class="col-sm-6">
                <h1 class="m-0 text-dark"><?php echo $__env->yieldContent('title'); ?></h1>
            </div>
            <div class="col-sm-6 ">
                <ol class="breadcrumb float-sm-right">
                    
                </ol>
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.permissions.index')); ?>"><?php echo $__env->yieldContent('title'); ?></a>
                        </li>
                    <li class="breadcrumb-item active"><?php echo $__env->yieldContent('subtitle'); ?></li>
                </ol>
            </div>
        </div>
    </div>
</div>
<section class="content">
    <div class="container-fluid">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.permission.index')->html();
} elseif ($_instance->childHasBeenRendered('5zw3TjM')) {
    $componentId = $_instance->getRenderedChildComponentId('5zw3TjM');
    $componentTag = $_instance->getRenderedChildComponentTagName('5zw3TjM');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('5zw3TjM');
} else {
    $response = \Livewire\Livewire::mount('admin.permission.index');
    $html = $response->html();
    $_instance->logRenderedChild('5zw3TjM', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</section>         
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.templates.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/kodir78/Sites/laman8/resources/views/admin/permission/index.blade.php ENDPATH**/ ?>