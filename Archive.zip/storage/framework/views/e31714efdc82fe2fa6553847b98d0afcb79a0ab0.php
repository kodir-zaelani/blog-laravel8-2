<div>
    <?php $__env->startSection("title"); ?>Detail Post <?php $__env->stopSection(); ?>
    <div class="cta-header pt-5">
        <div class="container-fluid">
            <div class="row justify-content-center pt-5">
                <div class="col-lg-6 col-md-6 col-12">
                    <div class="cta-header-title text-center">
                        <h2 class="py-4 text-uppercase font-weight-bold">DETAIL ARTIKEL</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Blog Archive -->
    <section class="section-detail" style="background-color:#f1f3f5">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-12">
                    <div class="row">
                        <div class="col-12">
                            <!-- Single blog -->
                            <div class="card">
                                <div class="card-img">
                                    <?php if($post->imageUrl): ?>
                                    <a href="<?php echo e(route('post.show', $post)); ?>"><img src="<?php echo e($post->imageUrl); ?>" class="card-img-top" alt="<?php echo e($post->title); ?>" class="w-100"></a>   
                                    <?php else: ?>
                                    <a href="<?php echo e(route('post.show', $post)); ?>"><img src="<?php echo e(url('')); ?>/assets/help/img/edu5.jpeg" class="card-img-top" alt="<?php echo e($post->title); ?>" 
                                        class="w-100"></a>
                                        <?php endif; ?>
                                        
                                    </div>
                                    <div class="card-body">
                                        <h2 class="card-title"><?php echo e($post->title); ?></h2>
                                        <ul class="blog-meta">
                                            <li class="author">
                                                <?php if($post->author->profile_photo_path): ?>
                                                <img src="<?php echo e(url('')); ?>/uploads/photos/users/photos_thumb/<?php echo e($post->author->profile_photo_path); ?>" ><span> <a href="#"><?php echo e($post->author->name); ?></a></span></li>
                                                <?php else: ?>
                                                <i class="fa fa-user"></i> <span> <a href="#"><?php echo e($post->author->name); ?></a></span>
                                                <?php endif; ?>
                                            </li>
                                            <li>
                                                <i class="fas fa-calendar-alt"></i> <?php echo e($post->created_at); ?> 
                                            </li>
                                            <li>
                                                
                                            </li>
                                            <li> <i class="fa fa-folder"></i>
                                                <a href="<?php echo e(route('categorypost.show', $post->categorypost->slug)); ?>"> <?php echo e($post->categorypost->title); ?></a> 
                                            </li>
                                            
                                        </ul>
                                        
                                        <?php echo $post->content; ?>

                                        <hr>
                                        Artikel ini telah dibaca sebanyak <strong><?php echo e($post->view_count); ?></strong> kali
                                        <?php if($post->tags_html ): ?>
                                        <p> <i class="fa fa-tags mr-2"></i> <?php echo $post->tags_html; ?></p>
                                        <?php endif; ?>
                                       
                                        <?php if($post->video): ?>
                                        <hr>
                                        <div class="pt-5 embed-responsive embed-responsive-16by9">
                                            <iframe height="450" src="<?php echo e($post->video); ?>"></iframe>
                                        </div>
                                        <div class="row justify-content-center">
                                            <div class="text-center col ">
                                                <p class="fw-lighter fst-italic"><?php echo e($post->caption_video); ?></p>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <!--/ End Single blog -->
                            </div> 
                            
                            
                            
                        </div>
                    </div>
                    <div class="col-md-4 col-lg-4 col-12">
                        <!-- Blog Sidebar -->
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.main.sidebarcategory')->html();
} elseif ($_instance->childHasBeenRendered('kpaOICx')) {
    $componentId = $_instance->getRenderedChildComponentId('kpaOICx');
    $componentTag = $_instance->getRenderedChildComponentTagName('kpaOICx');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('kpaOICx');
} else {
    $response = \Livewire\Livewire::mount('frontend.main.sidebarcategory');
    $html = $response->html();
    $_instance->logRenderedChild('kpaOICx', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.main.sidebarpopular')->html();
} elseif ($_instance->childHasBeenRendered('PsSsznh')) {
    $componentId = $_instance->getRenderedChildComponentId('PsSsznh');
    $componentTag = $_instance->getRenderedChildComponentTagName('PsSsznh');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('PsSsznh');
} else {
    $response = \Livewire\Livewire::mount('frontend.main.sidebarpopular');
    $html = $response->html();
    $_instance->logRenderedChild('PsSsznh', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.main.sidebartags')->html();
} elseif ($_instance->childHasBeenRendered('O71ZGYX')) {
    $componentId = $_instance->getRenderedChildComponentId('O71ZGYX');
    $componentTag = $_instance->getRenderedChildComponentTagName('O71ZGYX');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('O71ZGYX');
} else {
    $response = \Livewire\Livewire::mount('frontend.main.sidebartags');
    $html = $response->html();
    $_instance->logRenderedChild('O71ZGYX', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        
                        <!--/ End Blog Sidebar -->
                    </div>
                </div>
            </div>
        </section>
        
    </div>
    <?php /**PATH /Users/kodir78/Sites/laman8/resources/views/livewire/frontend/post/show.blade.php ENDPATH**/ ?>