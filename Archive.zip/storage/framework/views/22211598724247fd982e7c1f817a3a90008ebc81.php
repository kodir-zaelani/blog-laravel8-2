<div>
    <?php $__env->startSection("title"); ?>Category Post <?php $__env->stopSection(); ?>
    <div class="cta-header pt-5">
        <div class="container-fluid">
            <div class="row justify-content-center pt-5">
                <div class="col-lg-6 col-md-6 col-12">
                    <div class="cta-header-title text-center">
                        <?php if($categorypost->ImageThumbUrl): ?>
                            <img src="<?php echo e($categorypost->imageThumbUrl); ?>" 
                            style="width: 100px;height: 100px" 
                            class="img-fluid rounded-circle border border-warning" />
                        <?php else: ?>
                            <img src="<?php echo e(url('')); ?>/assets/help/img/edu5.jpeg"" 
                            style="width: 100px;height: 100px" 
                            class="img-fluid rounded-circle  border border-light shadow" />
                        <?php endif; ?>
                        <h2 class="py-4 text-uppercase font-weight-bold"><?php echo e($categorypost->title); ?></h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Blog Archive -->
    <section class="section-detail" style="background-color:#edf2f7">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                  <h3 class="font-weight-bold mb-3 text-uppercase">ARTIKEL DENGAN KATEGORI "<?php echo e($categorypost->title); ?>"</h3><hr>
                </div>
            </div>
            <div class="row">
                <div class="col-md-8 col-lg-8 col-12">
                    <div class="row">
                        <?php if(count($posts)): ?>
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-lg-6 col-12 mb-4">
                            <div class="card h-100 shadow-sm border-0 rounded-lg">
                                <div class="card-img">
                                    <?php if($post->ImageThumbUrl): ?>
                                    <a href="<?php echo e(route('post.show', $post)); ?>"><img src="<?php echo e($post->ImageThumbUrl); ?>" class="card-img-top" alt="<?php echo e($post->title); ?>" class="w-100">
                                    </a>   
                                    <?php else: ?>
                                    <a href="<?php echo e(route('post.show', $post)); ?>"><img src="<?php echo e(url('')); ?>/assets/help/img/edu5.jpeg" class="card-img-top" alt="<?php echo e($post->title); ?>" 
                                        class="w-100"></a>
                                    <?php endif; ?>
                                    </div>
                                    <div class="card-body">
                                        <?php if($post->tags_html ): ?>
                                        <p> <i class="fa fa-tags mr-2"></i> <?php echo $post->tags_html; ?></p>
                                        <?php endif; ?>
                                        <h4><a href="<?php echo e(route('post.show', $post)); ?>"><?php echo e($post->title); ?></a></h4>

                                    </div>
                                    <div class="card-footer bg-white">
                                        <span class="author">
                                            <?php if($post->author->photo): ?>
                                            <img src="<?php echo e(url('')); ?>/uploads/photos/users/photos_thumb/<?php echo e($post->author->photo); ?>"  ><span><a href="<?php echo e(route('author.show', $post->author->slug)); ?>"><?php echo e($post->author->name); ?></a></span></li>
                                            <?php else: ?>
                                            <i class="fa fa-user"></i> <span><a href="<?php echo e(route('author.show', $post->author->slug)); ?>"><?php echo e($post->author->name); ?></a></span>
                                            <?php endif; ?>
                                        </span>
                                    </div>
                                </div>
                        </div>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <h2 class="fw-bold" style="color:red">Nothing Result</h2>
                        <?php endif; ?>
                        </div>
                        <div class="row pt-10 justify-content-center">
                            <div class="col-12">
                                <!-- Pagination -->
                                <div class="pagination-main" >
                                    <?php echo e($posts->links()); ?>

                                </div>
                                <!--/ End Pagination -->
                            </div>
                        </div>	
                    </div>
                    <div class="col-md-4 col-lg-4 col-12">
                        <!-- Blog Sidebar -->
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.main.sidebarcategory')->html();
} elseif ($_instance->childHasBeenRendered('Wi2Wlhl')) {
    $componentId = $_instance->getRenderedChildComponentId('Wi2Wlhl');
    $componentTag = $_instance->getRenderedChildComponentTagName('Wi2Wlhl');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Wi2Wlhl');
} else {
    $response = \Livewire\Livewire::mount('frontend.main.sidebarcategory');
    $html = $response->html();
    $_instance->logRenderedChild('Wi2Wlhl', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.main.sidebarpopular')->html();
} elseif ($_instance->childHasBeenRendered('opAnpcE')) {
    $componentId = $_instance->getRenderedChildComponentId('opAnpcE');
    $componentTag = $_instance->getRenderedChildComponentTagName('opAnpcE');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('opAnpcE');
} else {
    $response = \Livewire\Livewire::mount('frontend.main.sidebarpopular');
    $html = $response->html();
    $_instance->logRenderedChild('opAnpcE', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.main.sidebartags')->html();
} elseif ($_instance->childHasBeenRendered('ViZ1FOO')) {
    $componentId = $_instance->getRenderedChildComponentId('ViZ1FOO');
    $componentTag = $_instance->getRenderedChildComponentTagName('ViZ1FOO');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ViZ1FOO');
} else {
    $response = \Livewire\Livewire::mount('frontend.main.sidebartags');
    $html = $response->html();
    $_instance->logRenderedChild('ViZ1FOO', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        
                        <!--/ End Blog Sidebar -->
                    </div>
                </div>
            </div>
        </section>
        <!--/ End Blog Archive -->
        <!-- Newsletter -->
        
        <!--/ End Newsletter -->
    </div>
    <?php /**PATH /Users/kodir78/Sites/laman8/resources/views/livewire/frontend/post/postcategory.blade.php ENDPATH**/ ?>