<div>
  <!-- Start CTA -->
  <section class="call-to-action overlay dzsparallaxer auto-init height-is-based-on-content use-loading mode-scroll out-of-bootstrap mt-5" data-options='{ direction: "normal"}'>
    <div class="overlay divimage dzsparallaxer--target bg-image" style="width: 100%; height: 150%; background-image: url(assets/img/38923ffd19be83834ef17c98567fa070.png)"></div>
    <div class="call-to-main">
      <div id="particles-js"></div>
      <div class="container">
        <div class="row">
          <div class="col-lg-10 offset-lg-1 col-12">
            <div class="text-inner">
              <div class="call-text">
                <h2>ARTIKEL BERDASARKAN KATEGORI</h2>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!--/ End CTA -->
  
  <section class="category-article" id="category-article">
    <div class="container">
      <div class="row justify-content-center">
        
        <?php $__currentLoopData = $categoryposts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
          <?php if(count($item->post()->get())): ?> 
            <div class="col-md-4 col-g-4 col-12 mb-4">
              <div class="card card-primary h-100 shadow-sm border-0 rounded-lg">
                <div class="card-header text-center">
                  <div class="h4"><?php echo e($item->title); ?></div>
                </div>
                <div class="card-body">
                  <div class="list-group">
                    <?php $__currentLoopData = $item->post()->take(4)->latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="" class="list-group-item list-group-item-action border-0 shadow-sm mb-2 rounded">
                      <div class="row justify-content-center">
                        <div class="col-4 d-flex align-items-center">
                          <?php if($post->imageThumbUrl): ?>
                                <img src="<?php echo e($post->imageThumburl); ?>" alt="<?php echo e($post->title); ?>"style="object-fit: cover;border-radius: .3rem;border-top-right-radius: .3rem;"
                                class="img-fluid "/>  
                            <?php else: ?>
                              <img src="<?php echo e(url('')); ?>/assets/help/img/edu5.jpeg" alt="post" style="object-fit: cover;border-radius: .3rem;border-top-right-radius: .3rem;"
                              class="img-fluid " />
                            <?php endif; ?>
                        </div>
                        <div class="col-8 d-flex align-items-center">
                          <span ><?php echo e($post->title); ?></span>
                        </div>
                      </div>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                  </div>
                </div>
                <div class="text-center card-footer bg-white">
                  <a href="<?php echo e(route('categorypost.show', $item->slug)); ?>" class="btn btn-primary mt-2">Lihat Lebih Banyak</a>
                </div>
              </div>
            </div>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
      </div>
    </div>
  </section>
  <!-- end category section -->
</div>
<?php /**PATH /Users/kodir78/Sites/laman8/resources/views/livewire/frontend/post/categorypostindex.blade.php ENDPATH**/ ?>