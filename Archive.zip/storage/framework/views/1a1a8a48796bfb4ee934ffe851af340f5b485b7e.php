<div>
    <!-- Home Banner -->
    <header class="main-banner">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 col-md-7">
                    <div class="row">
                        <div class="col-12">
                            <div class="banner-title">
                                <?php if($global_settings->title): ?>
                                    <h2><?php echo $global_settings->title; ?></h2>
                                <?php else: ?>
                                <h2>Laman Kreasi Nusantara</h2>
                                <?php endif; ?>
                                <?php if($global_settings->tagline): ?>
                                <h4 class="card-title"><?php echo $global_settings->tagline; ?></h4>
                                <?php else: ?>
                                    <h4>Ini bagian Tagline</h4>
                                <?php endif; ?> 
                                <?php if($global_settings->description): ?>
                                    <p><?php echo $global_settings->description; ?></p>
                                <?php else: ?>
                                    <p>Ini untuk descripsi singkat</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5 col-md-5">
                    <div class="main-banner-content">
                        <img src="<?php echo e(url('')); ?>/assets/frontend/image/hero.png" style="max-width: 90%">
                    </div>
                </div>
            </div>
        </div>
    </header>
</div>
<?php /**PATH /Users/kodir78/Sites/laman8/resources/views/livewire/frontend/main/banner.blade.php ENDPATH**/ ?>