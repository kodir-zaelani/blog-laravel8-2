<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="crst-token" content="<?php echo e(csrf_token()); ?>">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  
  <title><?php echo $__env->yieldContent('title', 'Laman Kreasi'); ?></title>
  <?php echo $__env->make('admin.templates.partials.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo view('laravel-trix::trixassets')->render(); ?>
  <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
<div class="wrapper">
    <?php echo $__env->make('admin.templates.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.templates.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <?php echo $__env->yieldContent('content'); ?>
  </div>
  <!-- /.content-wrapper -->

  <?php echo $__env->make('admin.templates.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>
<!-- ./wrapper -->

<?php echo $__env->make('admin.templates.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo \Livewire\Livewire::scripts(); ?>

</body>
</html>
<?php /**PATH /Users/kodir78/Sites/laman8/resources/views/admin/templates/default.blade.php ENDPATH**/ ?>