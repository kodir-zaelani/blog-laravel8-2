<div>
    <?php $__env->startSection("title"); ?>Post Search <?php $__env->stopSection(); ?>
    <div class="cta-header pt-5">
        <div class="container-fluid">
            <div class="row justify-content-center pt-5">
                <div class="col-lg-6 col-md-6 col-12">
                    <div class="cta-header-title text-center">
                        <div> <a href="https://www.freepik.com/free-icon/search_929060.htm#page=1&query=search&position=20" title="Freepik"><img src="<?php echo e(url('')); ?>/assets/frontend/image/search_monitor.png" alt="" srcset="" style="max-width: 30%"></a> </div>
                        <h2 class="py-4 text-uppercase font-weight-bold">Hasil Pencarian</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Blog Archive -->
    <section class="blogs grid-sidebar archive section" style="background-color:#edf2f7">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                  <h3 class="font-weight-bold mb-3 text-uppercase">ARTIKEL DENGAN KUNCI PENCARIAN " <?php echo e($searchterm); ?> "</h3><hr>
                </div>
            </div>
            <div class="row">
                <div class="col-md-8 col-lg-8 col-12">
                    <div class="row">
                        <?php if(count($posts)): ?>
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-lg-6 col-12 mb-4">
                            <div class="card h-100 shadow-sm border-0 rounded-lg">
                                <div class="card-img">
                                    <?php if($post->ImageThumbUrl): ?>
                                    <a href="<?php echo e(route('post.show', $post)); ?>"><img src="<?php echo e($post->ImageThumbUrl); ?>" class="card-img-top" alt="<?php echo e($post->title); ?>" class="w-100"></a>   
                                    <?php else: ?>
                                    <a href="<?php echo e(route('post.show', $post)); ?>"><img src="<?php echo e(url('')); ?>/assets/help/img/edu5.jpeg" class="card-img-top" alt="<?php echo e($post->title); ?>" 
                                        class="w-100"></a>
                                        <?php endif; ?>
                                        
                                    </div>
                                    <div class="card-body">
                                        <?php if($post->tags_html ): ?>
                                        <p> <i class="fa fa-tags mr-2"></i> <?php echo $post->tags_html; ?></p>
                                        <?php endif; ?>
                                        <h4><a href="<?php echo e(route('post.show', $post)); ?>"><?php echo e($post->title); ?></a></h4>
                                    </div>
                                    <div class="card-footer bg-white">
                                        <span class="author">
                                            <?php if($post->author->photo): ?>
                                            <img src="<?php echo e(url('')); ?>/uploads/photos/users/photos_thumb/<?php echo e($post->author->photo); ?>"  ><span><a href="<?php echo e(route('author.show', $post->author->slug)); ?>"><?php echo e($post->author->name); ?></a></span></li>
                                            <?php else: ?>
                                            <i class="fa fa-user"></i> <span><a href="<?php echo e(route('author.show', $post->author->slug)); ?>"><?php echo e($post->author->name); ?></a></span>
                                            <?php endif; ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <h2 class="fw-bold" style="color:red">Nothing Result</h2>
                            <?php endif; ?>
                    </div>
                    <div class="row pt-5 justify-content-center">
                        <div class="col-12">
                            <!-- Pagination -->
                            <div class="pagination-main" >
                                <?php echo e($posts->links()); ?>

                            </div>
                            <!--/ End Pagination -->
                        </div>
                    </div>	
                </div>
                <div class="col-md-4 col-lg-4 col-12">
                    <!-- Blog Sidebar -->
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.main.sidebarpopular')->html();
} elseif ($_instance->childHasBeenRendered('ePx4IxR')) {
    $componentId = $_instance->getRenderedChildComponentId('ePx4IxR');
    $componentTag = $_instance->getRenderedChildComponentTagName('ePx4IxR');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ePx4IxR');
} else {
    $response = \Livewire\Livewire::mount('frontend.main.sidebarpopular');
    $html = $response->html();
    $_instance->logRenderedChild('ePx4IxR', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.main.sidebarcategory')->html();
} elseif ($_instance->childHasBeenRendered('0lpu0Np')) {
    $componentId = $_instance->getRenderedChildComponentId('0lpu0Np');
    $componentTag = $_instance->getRenderedChildComponentTagName('0lpu0Np');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('0lpu0Np');
} else {
    $response = \Livewire\Livewire::mount('frontend.main.sidebarcategory');
    $html = $response->html();
    $_instance->logRenderedChild('0lpu0Np', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.main.sidebartags')->html();
} elseif ($_instance->childHasBeenRendered('O8uBrsE')) {
    $componentId = $_instance->getRenderedChildComponentId('O8uBrsE');
    $componentTag = $_instance->getRenderedChildComponentTagName('O8uBrsE');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('O8uBrsE');
} else {
    $response = \Livewire\Livewire::mount('frontend.main.sidebartags');
    $html = $response->html();
    $_instance->logRenderedChild('O8uBrsE', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    
                    <!--/ End Blog Sidebar -->
                </div>
            </div>
        </div>
    </section>
    <!--/ End Blog Archive -->
    <!-- Newsletter -->
    
    <!--/ End Newsletter -->

    <?php $__env->startPush('scripts'); ?>
        <script>
            $(document).ready(function(){
            // This event js triger when the modal is hidden
            $("#searchModal").on('hidden.bs.modal', function(){
                // alert('The modal is now hidden.');
                livewire.emit('forcedClosesearchModal');
            });
        });
        </script>
    <?php $__env->stopPush(); ?>
</div>
    <?php /**PATH /Users/kodir78/Sites/laman8/resources/views/livewire/frontend/post/search.blade.php ENDPATH**/ ?>