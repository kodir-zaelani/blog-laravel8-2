<div>
    <?php if($footer_menu): ?>
        <?php $__currentLoopData = $footer_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <a href="<?php echo e($menu['link']); ?>"><i class="fa fa-caret-right"></i><?php echo e(strtoupper($menu['label'])); ?></a>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>
<?php /**PATH /Users/kodir78/Sites/laman8/resources/views/livewire/frontend/main/footermenu.blade.php ENDPATH**/ ?>