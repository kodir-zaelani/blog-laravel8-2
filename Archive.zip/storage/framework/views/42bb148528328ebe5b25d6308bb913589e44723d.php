<div>
    <?php $__env->startSection("title"); ?>Detail Download <?php $__env->stopSection(); ?>
    
    
    <div class="row pt-5">
        <div class="col-12">
            <iframe src="<?php echo e(url('')); ?>/downloadfiles/<?php echo e($downloadfile->file); ?>" width="100%" height="600"></iframe>
            
            
        </div>
    </div>
</div>
<?php /**PATH /Users/kodir78/Sites/laman8/resources/views/livewire/frontend/download/detail.blade.php ENDPATH**/ ?>