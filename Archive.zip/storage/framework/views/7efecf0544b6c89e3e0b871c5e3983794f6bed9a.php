<div>
            <div class="row">
                <div class="col-md-3">
                    
                    <!-- Profile Image -->
                    <div class="card card-primary card-outline">
                        <div class="card-body box-profile">
                            <div class="text-center">
                                <?php if(auth()->user()->photo): ?>
                                    <img class="profile-user-img img-fluid img-circle"
                                    src="<?php echo e(url('')); ?>/uploads/photos/users/photos_thumb/<?php echo e(auth()->user()->photo); ?>"
                                    alt="<?php echo e(auth()->user()->name); ?>">
                                <?php else: ?>
                                    <img src="<?php echo e(url('')); ?>/assets/admin/dist/img/avatar.png" class="profile-user-img img-fluid img-circle" alt="<?php echo e(auth()->user()->name); ?>">
                                <?php endif; ?>
                               
                            </div>
                            
                            <h3 class="text-center profile-username"><?php echo e(auth()->user()->name); ?></h3>
                            
                            <ul class="mb-3 list-group list-group-unbordered">
                                <li class="list-group-item">
                                    <b>Followers</b> <a class="float-right">1,322</a>
                                </li>
                                <li class="list-group-item">
                                    <b>Following</b> <a class="float-right">543</a>
                                </li>
                                <li class="list-group-item">
                                    <b>Friends</b> <a class="float-right">13,287</a>
                                </li>
                            </ul>
                            
                            
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                    
                    <!-- About Me Box -->
                    <!-- /.card -->
                </div>
                <!-- /.col -->
                <div class="col-md-9">
                    <div class="card">
                        
                        <div class="p-2 card-header">
                            Settings
                        </div><!-- /.card-header -->
                        <div class="card-body">
                            <form wire:submit.prevent="update"  class="form-horizontal" >
                                <div class="form-group row">
                                    <label for="inputName" class="col-sm-3 col-form-label">Name</label>
                                    <div class="col-sm-9">
                                        <input wire:model="name" type="text"  class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter a full name">
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="inputName" class="col-sm-3 col-form-label">Bio</label>
                                    <div class="col-sm-9">
                                        <textarea wire:model="bio" id="" cols="30" rows="5" class="form-control <?php $__errorArgs = ['bio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter a full bio"></textarea>
                                       
                                        <?php $__errorArgs = ['bio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="photo" class="col-sm-3 col-form-label">Photo</label>
                                    <div class="col-sm-9">
                                        <input wire:model="photo" type="file"  class=" <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                                        <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
        
                                <div class="form-group row">
                                    <label  class="col-sm-3 col-form-label">New Password</label>
                                    <div class="col-sm-9">
                                        <input wire:model="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span  <span class="invalid-feedback"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                
                                <div class="form-group row">
                                    <?php if(!empty($password)): ?>
                                    <label  class="col-sm-3 col-form-label">Password Confirmation</label>
                                    <div class="col-sm-9">
                                        <input wire:model="password_confirmation" type="password" class="form-control" />
                                        <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span  <span class="invalid-feedback"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
        
                                    <label  class="col-sm-3 col-form-label">Current Password</label>
                                    <div class="col-sm-9">
                                        <input wire:model="current_password_for_password" type="password" class="form-control  <?php $__errorArgs = ['current_password_for_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
                                        <?php $__errorArgs = ['current_password_for_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span  <span class="invalid-feedback"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="form-group row">
                                    <div class="offset-sm-2 col-sm-9">
                                        <button wire:click="update" class="btn btn-danger mr-3">Update</button>
                                        <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-info"><i class="fa fa-dashboard" aria-hidden="true"></i>Dashboard</a>
                                    </div>
                                </div>
                            </form>
                        </div><!-- /.card-body -->
                    </div>
                    <!-- /.nav-tabs-custom -->
                </div>
                <!-- /.col -->
            </div>

    
    
    <?php $__env->startPush('styles'); ?>
        <!-- Jasny Bootstrap 4 -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/admin/plugins/jasny-bootstrap/4.0.0/css/jasny-bootstrap.min.css')); ?>"> 
    <?php $__env->stopPush(); ?>

    <?php $__env->startPush('scripts'); ?>
         <!-- Jasny Bootstrap 4 -->
        <script src="<?php echo e(asset('assets/admin/plugins/jasny-bootstrap/4.0.0/js/jasny-bootstrap.min.js')); ?>"></script>
    <?php $__env->stopPush(); ?>
</div>
<?php /**PATH /Users/kodir78/Sites/laman8/resources/views/livewire/admin/user/userprofile.blade.php ENDPATH**/ ?>