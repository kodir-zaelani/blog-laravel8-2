<div>
  
  <!-- Tags -->
  <div class="row mb-3">
    <div class="col-12">
      <div class="card card-primary " >
        <div class="card-body">
          <h4 class="font-weight-bold"><i class="fa fa-tags" aria-hidden="true"></i> TAGS</h4>
          <hr>
          <div class="tags">
            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('tag.show', $tag->slug)); ?>">
              <span class="badge bg-<?php echo e($tag->iclass); ?>"><?php echo e($tag->title); ?></span>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Tags -->
  
</div> 

<?php /**PATH /Users/kodir78/Sites/laman8/resources/views/livewire/frontend/main/sidebartags.blade.php ENDPATH**/ ?>