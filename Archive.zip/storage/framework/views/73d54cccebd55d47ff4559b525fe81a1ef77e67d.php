<div>
  
  <!-- section article -->
  <section class="article" id="article">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <h2 class="font-weight-bold mb-3">HOME</h2>
        </div>
      </div>
      <div class="row">
        <div class="col-md-8 col-lg-8 col-12">
          
          <?php if(count($posts)): ?>
          <div class="row">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 mb-4">
              <div class="card h-100 shadow-sm border-0 rounded-lg">
                <div class="card-img">
                  <?php if($post->ImageThumbUrl): ?>
                  <a href="<?php echo e(route('post.show', $post)); ?>">
                    <img src="<?php echo e($post->ImageThumbUrl); ?>"
                    class="card-img-top"
                    style="object-fit: cover; border-top-left-radius: .3rem;border-top-right-radius: .3rem;" alt="<?php echo e($post->title); ?>"/>
                  </a>   
                  <?php else: ?>
                  <a href="<?php echo e(route('post.show', $post)); ?>">
                    <img src="<?php echo e(url('')); ?>/assets/frontend/image/blog1.jpeg"
                    class="card-img-top"
                    style="object-fit: cover; border-top-left-radius: .3rem; border-top-right-radius: .3rem;" alt="<?php echo e($post->title); ?>"/>
                  </a>
                  <?php endif; ?>
                </div>
                <div class="card-body">
                  <?php if($post->tags_html ): ?>
                  <p> <i class="fa fa-tags mr-2"></i> <?php echo $post->tags_html; ?></p>
                  <?php endif; ?>
                  <h4><a href="<?php echo e(route('post.show', $post)); ?>"><?php echo e($post->title); ?></a></h4>
                </div>
                <div class="card-footer bg-white">
                  <span class="author">
                    <?php if($post->author->photo): ?>
                    <img src="<?php echo e(url('')); ?>/uploads/photos/users/photos_thumb/<?php echo e($post->author->photo); ?>"  ><span><a href="<?php echo e(route('author.show', $post->author->slug)); ?>"><?php echo e($post->author->name); ?></a></span></li>
                    <?php else: ?>
                    <i class="fa fa-user"></i> <span><a href="<?php echo e(route('author.show', $post->author->slug)); ?>"><?php echo e($post->author->name); ?></a></span>
                    <?php endif; ?>
                  </span>
                </div>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
          </div>
          <div class="row justify-content-center my-3">
            <div class="col-12 text-center">
              <a href="<?php echo e(route('post.all')); ?>" class="btn btn-primary">Lihat Lebih Banyak</a>
            </div>
          </div>
          <?php endif; ?>
        </div>
        <!-- Sidebar -->
        <div class="col-md-4 col-lg-4 col-12">
          <!-- Category section -->
          <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.main.sidebarcategory')->html();
} elseif ($_instance->childHasBeenRendered('V07erTX')) {
    $componentId = $_instance->getRenderedChildComponentId('V07erTX');
    $componentTag = $_instance->getRenderedChildComponentTagName('V07erTX');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('V07erTX');
} else {
    $response = \Livewire\Livewire::mount('frontend.main.sidebarcategory');
    $html = $response->html();
    $_instance->logRenderedChild('V07erTX', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
          <!-- end Category section -->
          <!-- Tags section -->
          <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.main.sidebartags')->html();
} elseif ($_instance->childHasBeenRendered('P0xhwak')) {
    $componentId = $_instance->getRenderedChildComponentId('P0xhwak');
    $componentTag = $_instance->getRenderedChildComponentTagName('P0xhwak');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('P0xhwak');
} else {
    $response = \Livewire\Livewire::mount('frontend.main.sidebartags');
    $html = $response->html();
    $_instance->logRenderedChild('P0xhwak', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
          <!-- end Tags section -->
          <!-- Popular Post -->
          <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.main.sidebarpopular')->html();
} elseif ($_instance->childHasBeenRendered('SF6ekG2')) {
    $componentId = $_instance->getRenderedChildComponentId('SF6ekG2');
    $componentTag = $_instance->getRenderedChildComponentTagName('SF6ekG2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('SF6ekG2');
} else {
    $response = \Livewire\Livewire::mount('frontend.main.sidebarpopular');
    $html = $response->html();
    $_instance->logRenderedChild('SF6ekG2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
          <!-- Popular Post -->
          
          <!-- Subscribe -->
          <!--
            <div class="card card-primary mb-3" >
              <div class="card-header" >
                <h4 class="card-title"><i class="fas fa-mail-bulk"></i> Newsletter</h4>
              </div>
              <div class="card-body">
                <p>Subscribe to our monthly newsletter. Every month we'll send you an awesome update!</p>
                <div class="subscribe">
                  <form action="#">
                    <input placeholder="Email Address" type="email">
                    <button type="submit"><i class="fa fa-paper-plane"></i></button>
                  </form>	
                </div>
              </div>
            </div>
          -->
          <!--/ End Subscribe -->
        </div>
        <!-- End Sidebar -->
      </div>
    </div>
  </section>
  <!--  section article -->
</div>
<?php /**PATH /Users/kodir78/Sites/laman8/resources/views/livewire/frontend/post/index.blade.php ENDPATH**/ ?>