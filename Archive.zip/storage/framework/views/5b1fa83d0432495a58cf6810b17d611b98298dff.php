<div>
  <nav class="navbar navbar-expand-lg navbar-dark fixed-top bg-dark nav-custom">
    <div class="container">
      <a class="navbar-brand" href="/"><?php echo $global_settings->title; ?></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse"
      aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
      <ul class="navbar-nav mr-auto mb-2 mb-md-0">
        <?php if($public_menu): ?>
        <?php $__currentLoopData = $public_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="nav-item <?php if($menu['child']): ?> dropdown <?php endif; ?>">
          <?php if($menu['child']): ?>
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-expanded="false">
            <?php echo e(strtoupper($menu['label'])); ?>

            <?php else: ?>
            <li class="nav-item">
              <a href="<?php echo e($menu['link']); ?>" class="nav-link">
                <?php echo e(strtoupper($menu['label'])); ?>

                <?php endif; ?>
                
              </a>
              <?php if($menu['child']): ?>
              <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                <?php $__currentLoopData = $menu['child']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                  <a href="<?php echo e($child['link']); ?>" class="dropdown-item"><?php echo e(strtoupper($child['label'])); ?></a></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <?php endif; ?>
              </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            </ul>
            <div class="d-flex">
              
              <button type="button" class="btn btn-outline-success btn-sm" data-toggle="modal" data-target="#searchModal">
                <i class="fa fa-search" style="color: white"></i>
              </button>
              
            </div>
          </div>
        </div>
      </nav>

      <?php $__env->startPush('modals'); ?>
        <!-- Modal -->
      <div class="modal fade" id="searchModal" tabindex="-1" aria-labelledby="searchModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="searchModalLabel">Post Search </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
                <div class="modal-body">
                    <form class="form" action="<?php echo e(route('post.search')); ?>">
                        <input type="text" id="term" value="<?php echo e(request('term')); ?>" class="form-control mb-3" required   name="term" placeholder="Search something for Posts ..." aria-label="Search">
                        <button class="btn btn-success" type="submit">Search</button>
                    </form>
                  
                </div>
                
            </div>
          </div>
      </div>
        
      <?php $__env->stopPush(); ?>
</div>
    <?php /**PATH /Users/kodir78/Sites/laman8/resources/views/livewire/frontend/main/header.blade.php ENDPATH**/ ?>