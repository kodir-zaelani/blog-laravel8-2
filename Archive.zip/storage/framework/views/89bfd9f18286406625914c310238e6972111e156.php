<div>
  <footer class="footer">
      <div class="container-fluid" style="background: rgb(255, 255, 255);">
          <div class="row p-4">
              <div class="col-md-4 mb-4">
                  <h5 class="font-weight-bold">KATEGORI</h5>
                  <hr>
                  <div class="single-widget links">
                      <ul class="list" style="list-style: none">
                          <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.main.footermenu')->html();
} elseif ($_instance->childHasBeenRendered('MqZesyG')) {
    $componentId = $_instance->getRenderedChildComponentId('MqZesyG');
    $componentTag = $_instance->getRenderedChildComponentTagName('MqZesyG');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('MqZesyG');
} else {
    $response = \Livewire\Livewire::mount('frontend.main.footermenu');
    $html = $response->html();
    $_instance->logRenderedChild('MqZesyG', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                      </ul>
                  </div>
              </div>
              <div class="col-md-4 mb-4">
                  <h5 class="font-weight-bold">POPULER</h5>
                  <hr>
                  <div class="single-widget posts">
                      <ul>
                          <?php $__currentLoopData = $global_latestFooter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li>
                              <?php if($post->ImageThumbUrl): ?>
                              <a href="<?php echo e(route('post.show', $post)); ?>"><img src="<?php echo e($post->ImageThumbUrl); ?>" alt="<?php echo e($post->title); ?>" ></a>   
                              <?php else: ?>
                              <a href="<?php echo e(route('post.show', $post)); ?>"><img src="<?php echo e(url('')); ?>/assets/help/img/edu5.jpeg" alt="<?php echo e($post->title); ?>" 
                                  ></a>
                                  <?php endif; ?>
                                  
                                  <a href="<?php echo e(route('post.show', $post->slug)); ?>"><?php echo e($post->title); ?></a>
                              </li>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </ul>
                      </div>
                  </div>
                  <div class="col-md-4 mb-4 ">
                      <h5 class="font-weight-bold">KONTAK</h5>
                      <hr>
                      <div class="text-left">
                          <p>
                              Kritik, saran, dan tawaran kerja sama atau kolaborasi bisa dikirimkan ke alamat kontak dibawah
                          </p>
                          <p>
                              <a href="https://api.whatsapp.com/send?phone=6208115986878&text=Assalamualaikum" target="_blank"> 
                                  <i class="fab fa-whatsapp"></i> 
                                  <?php if($global_settings->whatapss): ?>
                                  <?php echo e($global_settings->whatapss); ?>

                                  <?php else: ?>
                                  08115986878
                                  <?php endif; ?>
                              </a>
                          </p>
                          <p>
                              <a href="mailto:com.<?php echo e($global_settings->email); ?>"> 
                                  <i class="fa fa-envelope"></i> 
                                  <?php if($global_settings->email): ?>
                                  <?php echo e($global_settings->email); ?>

                                  <?php else: ?>
                                  laman.kreasi@gmail.com
                                  <?php endif; ?>
                              </a>
                          </p>
                      </div>
                  </div>
              </div>
          </div>
          <div class="container-fluid bg-dark">
              <div class="row p-3">
                  <div class="text-center text-white font-weight-bold">
                      © 2020 - <?php echo  date('Y'); ?> | <?php echo e($global_settings->website); ?> 
                  </div>
              </div>
          </div>
      </footer>
  </div>
  <?php /**PATH /Users/kodir78/Sites/laman8/resources/views/livewire/frontend/main/footer.blade.php ENDPATH**/ ?>