
<?php $__env->startSection("title"); ?>Roles <?php $__env->stopSection(); ?>
<?php $__env->startSection("subtitle"); ?>Edit Role <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-header">
    <div class="container-fluid">
        <div class="mb-2 row">
            <div class="col-sm-6">
                <h1 class="m-0 text-dark"><?php echo $__env->yieldContent('title'); ?></h1>
            </div>
            <div class="col-sm-6 ">
                <ol class="breadcrumb float-sm-right">
                    
                </ol>
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.roles.index')); ?>"><?php echo $__env->yieldContent('title'); ?></a>
                    </li>
                    <li class="breadcrumb-item active"><?php echo $__env->yieldContent('subtitle'); ?></li>
                </ol>
            </div>
        </div>
    </div>
</div>
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title"><i class="fas fa-unlock"></i>  Edit Roles</h3>
                    </div>
                    <div class="card-body">               
                        <form action="<?php echo e(route('admin.roles.update', $role->id)); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="form-group">
                                <label>NAMA ROLE</label>
                                <input type="text" name="name" value="<?php echo e(old('name', $role->name)); ?>" placeholder="Masukkan Nama Role"
                                class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback" style="display: block">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div class="form-group">
                                <label class="font-weight-bold">PERMISSIONS:</label><br/>
                                
                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" 
                                    name="permissions[]" 
                                    value="<?php echo e($permission->name); ?>" 
                                    id="check-<?php echo e($permission->id); ?>" 
                                    <?php if($role->permissions->contains($permission)): ?> checked <?php endif; ?>>
                                    <label class="form-check-label" for="check-<?php echo e($permission->id); ?>">
                                        <?php echo e($permission->name); ?>

                                    </label>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            
                            <button class="mr-1 btn btn-primary btn-submit btn-sm" type="submit"><i class="fa fa-paper-plane"></i>
                                UPDATE</button>
                                <a href="<?php echo e(route('admin.roles.index')); ?>" class="btn btn-info btn-sm" >BACK</a>
                                <button class="btn btn-warning btn-reset btn-sm" type="reset"><i class="fa fa-redo"></i> RESET</button>
                                
                            </form>
                        </div>
                    </div>
                </div>
            </div>   
        </div>
    </section> 
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.templates.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/kodir78/Sites/laman8/resources/views/admin/role/edit.blade.php ENDPATH**/ ?>