<div>
    <?php $__env->startSection("title"); ?>All Post <?php $__env->stopSection(); ?>
    <div class="cta-header pt-5">
        <div class="container-fluid">
            <div class="row justify-content-center pt-5">
                <div class="col-lg-6 col-md-6 col-12">
                    <div class="cta-header-title text-center">
                        
                        <h2 class="py-4 text-uppercase font-weight-bold">SEMUA ARTIKEL</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- All Post Archive -->
    <section class="blogs" style="background-color:#edf2f7">
        <div class="container-fluid " >
            <div class="row">
                <div class="col-12">
                  <h2 class="font-weight-bold mb-3">ARTIKEL</h2>
                  <hr>
                </div>
              </div>
            <div class="row ">
                <div class="col-md-12 col-lg-12 col-12">
                    <?php if(count($posts)): ?>
                    <div class="row justify-content-center">
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 col-lg-4 col-12 mb-4">
                            <div class="card h-100 shadow-sm border-0 rounded-lg">
                                <div class="card-img">
                                    <?php if($post->ImageThumbUrl): ?>
                                    <a href="<?php echo e(route('post.show', $post)); ?>"><img src="<?php echo e($post->ImageThumbUrl); ?>" class="card-img-top" alt="<?php echo e($post->title); ?>" class="w-100">
                                    </a>   
                                    <?php else: ?>
                                    <a href="<?php echo e(route('post.show', $post)); ?>"><img src="<?php echo e(url('')); ?>/assets/help/img/edu5.jpeg" class="card-img-top" alt="<?php echo e($post->title); ?>" 
                                        class="w-100"></a>
                                        <?php endif; ?>
                                    </div>
                                    <div class="card-body">
                                        <?php if($post->tags_html ): ?>
                                        <p> <i class="fa fa-tags mr-2"></i> <?php echo $post->tags_html; ?></p>
                                        <?php endif; ?>
                                        <h4><a href="<?php echo e(route('post.show', $post)); ?>"><?php echo e($post->title); ?></a></h4>

                                    </div>
                                    <div class="card-footer bg-white">
                                        <span class="author">
                                            <?php if($post->author->photo): ?>
                                            <img src="<?php echo e(url('')); ?>/uploads/photos/users/photos_thumb/<?php echo e($post->author->photo); ?>"  ><span><a href="<?php echo e(route('author.show', $post->author->slug)); ?>"><?php echo e($post->author->name); ?></a></span></li>
                                            <?php else: ?>
                                            <i class="fa fa-user"></i> <span><a href="<?php echo e(route('author.show', $post->author->slug)); ?>"><?php echo e($post->author->name); ?></a></span>
                                            <?php endif; ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        <!-- end berita section -->
                        <?php else: ?>
                        <h2 class="fw-bold" style="color:red">Nothing Post Found</h2>
                        <?php endif; ?>
                    </div>
                    <div class="pt-5 row justify-content-center">
                        <div class="col-12 text-center">
                            <!-- Pagination -->
                                <?php echo e($posts->links()); ?>

                            <!--/ End Pagination -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End All Post Archive -->
</div>
<?php /**PATH /Users/kodir78/Sites/laman8/resources/views/livewire/frontend/post/postsall.blade.php ENDPATH**/ ?>