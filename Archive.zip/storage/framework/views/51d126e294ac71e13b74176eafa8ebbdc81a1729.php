<script src="<?php echo e(asset('assets/admin/plugins/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js')); ?>"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>

<script src="<?php echo e(asset('assets/admin/dist/js/adminlte.js')); ?>"></script>

<?php /**PATH /Users/kodir78/Sites/laman8/resources/views/admin/templates/partials/scripts.blade.php ENDPATH**/ ?>