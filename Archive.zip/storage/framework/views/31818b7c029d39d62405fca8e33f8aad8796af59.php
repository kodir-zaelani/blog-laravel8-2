<?php $__env->startSection('title', 'My Profile'); ?> 
<?php $__env->startSection('subtitle', 'My Profile'); ?> 
<?php $__env->startSection('content'); ?>
<div class="content-header">
    <div class="container-fluid">
        <div class="mb-2 row">
            <div class="col-sm-6">
                <h1 class="m-0 text-dark"><?php echo $__env->yieldContent('title'); ?></h1>
            </div>
            <div class="col-sm-6 ">
                <ol class="breadcrumb float-sm-right">
                    
                </ol>
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active"><?php echo $__env->yieldContent('subtitle'); ?></li>
                </ol>
            </div>
        </div>
    </div>
</div>
<section class="content">
    <div class="container-fluid">
       <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.user.userprofile')->html();
} elseif ($_instance->childHasBeenRendered('ho4kqCI')) {
    $componentId = $_instance->getRenderedChildComponentId('ho4kqCI');
    $componentTag = $_instance->getRenderedChildComponentTagName('ho4kqCI');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ho4kqCI');
} else {
    $response = \Livewire\Livewire::mount('admin.user.userprofile');
    $html = $response->html();
    $_instance->logRenderedChild('ho4kqCI', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</section>         
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
 <!-- Sweet Alert 2 -->
 <link rel="stylesheet" href="<?php echo e(asset('assets/admin/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
 <!-- Sweet Alert 2 -->
<script src="<?php echo e(asset('assets/admin/plugins/sweetalert2/sweetalert2.min.js')); ?>"></script>



<script>
    //flash message
    <?php if(session()-> has('success')): ?>

    swal.fire({
        icon: "success",
        title: "BERHASIL!",
        text: "<?php echo e(session('success')); ?>",
        // timer: 1500,
        showConfirmButton: true,
        showCancelButton: false,
    });
    <?php elseif(session()-> has('error')): ?>
    swal.fire({
        icon: "error",
        title: "GAGAL!",
        text: "<?php echo e(session('error')); ?>",
        // timer: 1500,
        showConfirmButton: true,
        showCancelButton: false,
    });
    <?php endif; ?>
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.templates.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/kodir78/Sites/laman8/resources/views/admin/user/profile.blade.php ENDPATH**/ ?>