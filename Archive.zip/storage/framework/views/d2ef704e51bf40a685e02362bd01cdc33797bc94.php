 <!-- Main Sidebar Container -->
 <aside class="main-sidebar sidebar-dark-primary elevation-4">
  <!-- Brand Logo -->
  <a href="#" class="brand-link">
    
    <img src="<?php echo e(url('')); ?>/assets/admin/dist/img/AdminLTELogo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3"
    style="opacity: .8">
    <span class="brand-text font-weight-light"><?php echo e(config('app.name', 'Laman Kreasi')); ?></span>
  </a>
  
  <!-- Sidebar -->
  <div class="sidebar">
    <!-- Sidebar user panel (optional) -->
    
    
    <!-- Sidebar Menu -->
    <nav class="mt-2">
      <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
        
        <li class="nav-item">
          <a href="<?php echo e(route('admin.dashboard')); ?>" class="nav-link <?php echo e(setActive('backend/dashboard')); ?>">
            <i class="nav-icon fas fa-tachometer-alt"></i>
            <p>
              Dashboard
            </p>
          </a>
        </li>
        
        
         <li class="nav-item has-treeview <?php echo e(setOpen('backend/categoryposts'). setOpen('backend/subcategoryposts'). setOpen('backend/tags'). setOpen('backend/posts'). setOpen('backend/setarticles')); ?>">
          <?php if(auth()->user()->can('categoryposts.index') || auth()->user()->can('subcategoryposts.index') || auth()->user()->can('setarticles.index') || auth()->user()->can('tags.index') || auth()->user()->can('posts.index')): ?>
          <a href="#" class="nav-link <?php echo e(setActive('backend/categoryposts'). setActive('backend/subcategoryposts'). setActive('backend/setarticles'). setActive('backend/tags'). setActive('backend/posts')); ?>">
            <i class="nav-icon far fa-newspaper"></i>
            <p>
              Posts Management
              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <?php endif; ?>
          <ul class="nav nav-treeview">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts.index')): ?>
            <li class="nav-item">
              <a href="<?php echo e(route('admin.posts.index')); ?>" class="nav-link <?php echo e(setActive('backend/posts')); ?>">
                <i class="fas fa-blog nav-icon"></i>
                <p>
                  Posts
                </p>
              </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('categoryposts.index')): ?>
            <li class="nav-item">
              <a href="<?php echo e(route('admin.categoryposts.index')); ?>" class="nav-link <?php echo e(setActive('backend/categoryposts')); ?>">
                <i class="fas fa-folder nav-icon"></i>
                <p>
                  Category
                </p>
              </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('subcategoryposts.index')): ?>
            <li class="nav-item">
              <a href="<?php echo e(route('admin.subcategoryposts.index')); ?>" class="nav-link <?php echo e(setActive('backend/subcategoryposts')); ?>">
                <i class="fas fa-folder nav-icon"></i>
                <p>
                  Sub Category
                </p>
              </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tags.index')): ?>
            <li class="nav-item">
              <a href="<?php echo e(route('admin.tags.index')); ?>" class="nav-link <?php echo e(setActive('backend/tags')); ?>">
                <i class="fas fa-tags nav-icon"></i>
                <p>
                  Tags
                </p>
              </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('setarticles.index')): ?>
            <li class="nav-item">
              <a href="<?php echo e(route('admin.setarticles.index')); ?>" class="nav-link <?php echo e(setActive('backend/setarticles')); ?>">
                <i class="fas fa-blog nav-icon"></i>
                <p>
                  Set Article
                </p>
              </a>
            </li>
            <?php endif; ?>
            
          </ul>
        </li>
        
        <li class="nav-item has-treeview <?php echo e(setOpen('backend/categorypages'). setOpen('backend/pages')); ?> ">
          <?php if(auth()->user()->can('categorypages.index') || auth()->user()->can('pages.index')): ?>
          <a href="#" class="nav-link <?php echo e(setActive('backend/categorypages'). setActive('backend/pages')); ?>">
            <i class="nav-icon fas fa-copy"></i>
            <p>
              Pages Management
              <i class="fas fa-angle-left right"></i>
            </p>
          </a>
          <?php endif; ?>
          <ul class="nav nav-treeview">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('categorypages.index')): ?>
            <li class="nav-item">
              <a href="<?php echo e(route('admin.categorypages.index')); ?>" class="nav-link <?php echo e(setActive('backend/categorypages')); ?>">
                <i class="fas fa-folder nav-icon"></i>
                <p>Category Pages</p>
              </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pages.index')): ?>
            <li class="nav-item">
              <a href="<?php echo e(route('admin.pages.index')); ?>" class="nav-link <?php echo e(setActive('backend/pages')); ?>">
                <i class="fas fa-file nav-icon"></i>
                <p>Pages</p>
              </a>
            </li>
            <?php endif; ?>
          </ul>
        </li>
        
        <li class="nav-item has-treeview <?php echo e(setOpen('backend/sliders'). setOpen('backend/albums'). setOpen('backend/photos')); ?> ">
          <?php if(auth()->user()->can('photos.index') || auth()->user()->can('sliders.index') || auth()->user()->can('albums.index')): ?>
          <a href="#" class="nav-link <?php echo e(setActive('backend/sliders'). setActive('backend/photos'). setActive('backend/albums')); ?>">
            <i class="fas fa-swatchbook"></i>
            <p>
              Galeries 
              <i class="fas fa-angle-left right"></i>
            </p>
          </a>
          <?php endif; ?>
          <ul class="nav nav-treeview">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sliders.index')): ?>
            <li class="nav-item">
              <a href="<?php echo e(route('admin.sliders.index')); ?>" class="nav-link <?php echo e(setActive('backend/sliders')); ?>">
                <i class="fab fa-slideshare nav-icon"></i>
                <p>
                  Sliders
                </p>
              </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('albums.index')): ?>
            <li class="nav-item">
              <a href="<?php echo e(route('admin.albums.index')); ?>" class="nav-link <?php echo e(setActive('backend/albums')); ?>">
                <i class="fas fa-images nav-icon"></i>
                <p>
                  Albums Portfolio
                </p>
              </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('photos.index')): ?>
            <li class="nav-item">
              <a href="<?php echo e(route('admin.photos.index')); ?>" class="nav-link <?php echo e(setActive('backend/photos')); ?>">
                <i class="fas fa-images nav-icon"></i>
                <p>
                  Portfolio
                </p>
              </a>
            </li>
            <?php endif; ?>
          </ul>
        </li>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('downloadfiles.index')): ?>
            <li class="nav-item">
              <a href="<?php echo e(route('admin.downloadfiles.index')); ?>" class="nav-link <?php echo e(setActive('backend/downloadfiles')); ?>">
                <i class="fas fa-file-download"></i> 
                <p>
                  Download File
                </p>
              </a>
            </li>
            <?php endif; ?>
        <li class="nav-item has-treeview <?php echo e(setOpen('backend/settings'). setOpen('backend/socialmedia'). setOpen('backend/principles'). setOpen('backend/menus')); ?> ">
          <?php if(auth()->user()->can('settings.index') || auth()->user()->can('menus.index') || auth()->user()->can('socialmedia.index')): ?>
          <a href="#" class="nav-link <?php echo e(setActive('backend/settings'). setActive('backend/menus'). setActive('backend/socialmedia')); ?>">
            <i class="fas fa-tools"></i>
            <p>
              Configuration
              <i class="fas fa-angle-left right"></i>
            </p>
          </a>
          <?php endif; ?>
          <ul class="nav nav-treeview">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('settings.index')): ?>
            <li class="nav-item ">
              <a href="<?php echo e(route('admin.settings.index')); ?>" class="nav-link <?php echo e(setActive('backend/settings')); ?>">
                <i class="fas fa-school"></i>
                <p>
                  Web Setting
                </p>
              </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('socialmedia.index')): ?>
            <li class="nav-item">
              <a href="<?php echo e(route('admin.socialmedia.index')); ?>" class="nav-link <?php echo e(setActive('backend/socialmedia')); ?>">
                <i class="far fa-thumbs-up"></i>
                <p>
                  Social Media
                </p>
              </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('menus.index')): ?>
            <li class="nav-item ">
              <a href="<?php echo e(route('admin.menus.index')); ?>" class="nav-link <?php echo e(setActive('backend/menus')); ?>">
                <i class="fas fa-bars nav-icon"></i>
                <p>
                  Menu Frontend
                </p>
              </a>
            </li>
            <?php endif; ?>
          </ul>
        </li> 
       
        <li class="nav-item has-treeview <?php echo e(setOpen('backend/roles'). setOpen('backend/permissions'). setOpen('backend/users')); ?> ">
          <?php if(auth()->user()->can('roles.index') || auth()->user()->can('permissions.index') || auth()->user()->can('users.index')): ?>
          <a href="#" class="nav-link <?php echo e(setActive('backend/roles'). setActive('backend/permissions'). setActive('backend/users')); ?>">
            <i class="fas fa-user-tag nav-icon"></i>
            <p>
              Users Management
              <i class="fas fa-angle-left right"></i>
            </p>
          </a>
          <?php endif; ?>
          <ul class="nav nav-treeview">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.index')): ?>
            <li class="nav-item ">
              <a href="<?php echo e(route('admin.roles.index')); ?>" class="nav-link <?php echo e(setActive('backend/roles')); ?>">
                <i class="fas fa-shield-alt nav-icon"></i>
                <p>Roles</p>
              </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permissions.index')): ?>
            <li class="nav-item">
              <a href="<?php echo e(route('admin.permissions.index')); ?>" class="nav-link <?php echo e(setActive('backend/permissions')); ?>">
                <i class="fas fa-lock nav-icon"></i>
                <p>Permission</p>
              </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.index')): ?>
            <li class="nav-item">
              <a href="<?php echo e(route('admin.users.index')); ?>" class="nav-link <?php echo e(setActive('backend/users')); ?>">
                <i class="fas fa-users nav-icon"></i>
                <p>Users</p>
              </a>
            </li>
            <?php endif; ?>
          </ul>
        </li> 
      </ul>
    </nav>
    <!-- /.sidebar-menu -->
  </div>
  <!-- /.sidebar -->
</aside><?php /**PATH /Users/kodir78/Sites/laman8/resources/views/admin/templates/partials/sidebar.blade.php ENDPATH**/ ?>