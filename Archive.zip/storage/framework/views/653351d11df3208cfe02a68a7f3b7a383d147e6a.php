<div>
    <div class="row">
        <div class="col-12">
            <!-- Popular Post -->
            <div class="card mb-3">
                <div class="card-body">
                  <div class="single-sidebar post-tab">
                    <!-- Tab Nav -->
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                      <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#popular" role="tab">Populer</a></li>
                      <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#recent" role="tab">Terbaru</a></li>
                      <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#featured" role="tab">Pilihan</a></li>
                    </ul>
                    <!--/ End Tab Nav -->
                    <div class="tab-content" id="myTabContent">
                      <!-- Popular Posts -->
                      <div class="tab-pane fade show active" id="popular" role="tabpanel" >
                        <!-- Single Post -->
                        <?php $__currentLoopData = $post_popular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="single-post">
                                <?php if($post->imageThumbUrl): ?>
                                <div class="post-img">
                                    <a href="<?php echo e(route('post.show', $post)); ?>"><img src="<?php echo e($post->imageThumburl); ?>" alt="<?php echo e($post->title); ?>"></a>   
                                </div>
                                <?php else: ?>
                                <div class="post-img">
                                    <img src="<?php echo e(url('')); ?>/assets/help/img/edu5.jpeg" alt="post">
                                </div>
                                <?php endif; ?>
                                <div class="post-info">
                                    <h4><a href="<?php echo e(route('post.show', $post)); ?>"><?php echo e($post->title); ?></a></h4>
                                    <p><i class="fa fa-calendar"></i><?php echo e($post->CreatedAt); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!--/ End Single Post -->
                      </div>
                      <!--/ End Popular Posts -->
                      <!-- Popular Posts -->
                      <div class="tab-pane fade" id="recent" role="tabpanel" >
                        
                        <!-- Single Post -->
                        <?php $__currentLoopData = $posts_latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <div class="single-post">
                             <?php if($post->imageThumbUrl): ?>
                             <div class="post-img">
                                 <a href="<?php echo e(route('post.show', $post)); ?>"><img src="<?php echo e($post->imageThumburl); ?>" alt="<?php echo e($post->title); ?>"></a>   
                             </div>
                             <?php else: ?>
                             <div class="post-img">
                                <img src="<?php echo e(url('')); ?>/assets/help/img/edu5.jpeg" alt="post">
                             </div>
                             <?php endif; ?>
                             <div class="post-info">
                                 <h4><a href="<?php echo e(route('post.show', $post)); ?>"><?php echo e($post->title); ?></a></h4>
                                 <p><i class="fa fa-calendar"></i><?php echo e($post->CreatedAt); ?></p>
                             </div>
                         </div>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!--/ End Single Post -->
                        
                      </div>
                      <!--/ End Popular Posts -->
                      <!-- Popular Posts -->
                      <div class="tab-pane fade" id="featured" role="tabpanel" >
                        
                        <!-- Single Post -->
                        <?php $__currentLoopData = $posts_selection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <div class="single-post">
                             <?php if($post->imageThumbUrl): ?>
                             <div class="post-img">
                                 <a href="<?php echo e(route('post.show', $post)); ?>"><img src="<?php echo e($post->imageThumburl); ?>" alt="<?php echo e($post->title); ?>"></a>   
                             </div>
                             <?php else: ?>
                             <div class="post-img">
                                <img src="<?php echo e(url('')); ?>/assets/help/img/edu5.jpeg" alt="post">
                             </div>
                             <?php endif; ?>
                             <div class="post-info">
                                 <h4><a href="<?php echo e(route('post.show', $post)); ?>"><?php echo e($post->title); ?></a></h4>
                                 <p><i class="fa fa-calendar"></i><?php echo e($post->CreatedAt); ?></p>
                             </div>
                         </div>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!--/ End Single Post -->
                        
                      </div>
                      <!--/ End Popular Posts -->
                    </div>
                  </div>
                </div>
              </div>
              <!-- Popular Post -->
        </div>
    </div>
</div>
<?php /**PATH /Users/kodir78/Sites/laman8/resources/views/livewire/frontend/main/sidebarpopular.blade.php ENDPATH**/ ?>